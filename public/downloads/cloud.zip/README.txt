﻿DitakNet placeholder package: cloud

This is a temporary download file.
Replace with the real installer/package when ready.
