﻿DitakNet placeholder package: lan-scan

This is a temporary download file.
Replace with the real installer/package when ready.
